package com.example.permissions

import android.Manifest
import android.content.Intent
import com.example.permissions.R
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileWriter
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val fileName = "my_file.txt"
    private lateinit var writeToFileButton: Button
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<Array<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        writeToFileButton = findViewById(R.id.writeToFileButton)

        requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            val writeGranted = permissions.getOrDefault(Manifest.permission.WRITE_EXTERNAL_STORAGE, false)
            if (writeGranted) {
                Toast.makeText(this, "Write permission granted", Toast.LENGTH_SHORT).show()
                writeFileToSDCard() // Proceed with writing
            } else {
                Toast.makeText(this, "Write permission denied", Toast.LENGTH_SHORT).show()
            }
        }

        writeToFileButton.setOnClickListener {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) { // Request permissions on Android 9 and below
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                } else {
                    writeFileToSDCard() // Permission already granted
                }
            } else {
                // On Android 10 and above, for app-specific directory or MediaStore, no direct permission needed
                // For broader access, you might need to use the Storage Access Framework (SAF)
                writeFileToSDCardScopedStorage() // Example for app-specific directory
            }
        }
    }

    private fun writeFileToSDCard() {
        val externalStorageDir = Environment.getExternalStorageDirectory()
        val myFile = File(externalStorageDir, fileName)

        try {
            FileWriter(myFile).use { writer ->
                writer.write("Hello from my app!")
                Toast.makeText(this, "File written to: ${myFile.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Error writing file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun writeFileToSDCardScopedStorage() {
        // For writing to your app-specific directory on external storage (no permission needed)
        val externalAppDir = getExternalFilesDir(null) // or getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) etc.
        externalAppDir?.let {
            val myFile = File(it, fileName)
            try {
                FileWriter(myFile).use { writer ->
                    writer.write("Hello from my app (Scoped Storage)!")
                    Toast.makeText(this, "File written to: ${myFile.absolutePath}", Toast.LENGTH_LONG).show()
                }
            } catch (e: IOException) {
                e.printStackTrace()
                Toast.makeText(this, "Error writing file (Scoped)", Toast.LENGTH_SHORT).show()
            }
        } ?: run {
            Toast.makeText(this, "External app directory not available", Toast.LENGTH_SHORT).show()
        }

        // For adding media files (images, videos, audio), use MediaStore APIs.
        // This involves creating ContentValues and inserting them into the MediaStore content provider.
    }
}

